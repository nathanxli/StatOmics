# test2.R

# Function that returns the same string as input
echo <- function(input_string) {
    return(input_string)
}